﻿CREATE TABLE logindata (
    
    username VARCHAR (100) NOT NULL,
    password varchar (100) NOT NULL,
);


INSERT INTO logindata (username, password)
VALUES
('vijay','vijay123'),
('sunil','sunil123');
