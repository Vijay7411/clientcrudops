using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;

namespace LoginAPI.Pages.login
{
    public class loginModel : PageModel
    {
        private readonly IConfiguration _configuration;

        public loginModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [BindProperty]
        public string username { get; set; }

        [BindProperty]
        public string password { get; set; }

        public string message { get; set; }

        // Handles the GET request
        public void OnGet()
        {
            // Optionally you can handle any GET request logic here
        }

        // Handles the POST request (login form submission)
        public void OnPost()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // SQL query to check if the entered username and password exist in the database
                    string sql = "SELECT COUNT(1) FROM logindata WHERE username = @username AND password = @password";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        // Prevent SQL Injection by using parameters
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@password", password);

                        int userCount = (int)command.ExecuteScalar();

                        // If the user exists, display success, else show failure message
                        if (userCount == 1)
                        {
                            message = "Login successful";
                        }
                        else
                        {
                            message = "Login failed. Invalid username or password.";
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Handle potential database connection errors
                message = "An error occurred while connecting to the database: " + ex.Message;
            }
        }
    }

    // Class to represent login data (optional if you need it elsewhere)
    public class LoginInfo
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
