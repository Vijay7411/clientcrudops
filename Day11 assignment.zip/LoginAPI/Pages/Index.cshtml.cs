using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace LoginAPI.Pages
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public string username { get; set; }

        [BindProperty]
        public string password { get; set; }

        public string message { get; set; }

        public void OnGet()
        {

        }
        public void OnPost() 
        {
            if (username == "admin" && password == "admin"){
                message = "login successful";
                //return Page();
            }
            else
            {
                message = "login Failed";
            }
        }
    }
}
